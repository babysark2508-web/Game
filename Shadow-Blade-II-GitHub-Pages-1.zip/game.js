const c=document.getElementById('c'),x=c.getContext('2d');let W,H,D,run=false,last=0,cam=0;
const P={x:130,y:360,w:24,h:42,vx:0,vy:0,hp:100,mp:100,ground:false,face:1,atk:0,skill:0,dash:0,inv:0};
let keys={},world=3300,gems=0,gold=91737,kills=0,shake=0,flash=0,msgT=0,parts=[],shots=[],enemies=[],platforms=[],boss=null;
function resize(){D=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;c.width=W*D;c.height=H*D;x.setTransform(D,0,0,D,0,0)}addEventListener('resize',resize);resize();
function say(t){hint.textContent=t;hint.style.opacity=1;msgT=1300}
function reset(){
 P.x=130;P.y=360;P.vx=P.vy=0;P.hp=100;P.mp=100;P.atk=P.skill=P.dash=P.inv=0;cam=0;gems=0;gold=91737;kills=0;boss=null;parts=[];shots=[];
 platforms=[[0,500,520,76],[590,500,470,76],[1120,500,520,76],[1700,500,480,76],[2240,500,600,76],[2920,500,520,76],
 [210,390,250,22],[570,330,260,22],[930,390,260,22],[1180,300,250,22],[1480,390,260,22],[1750,315,240,22],[2050,395,250,22],[2350,310,250,22],[2640,390,250,22],[2920,290,260,22],
 [760,200,260,20],[1500,190,250,20],[2180,180,250,20]];
 enemies=[E(700,450,'eye'),E(970,340,'eye'),E(1280,450,'knight'),E(1510,340,'eye'),E(1830,265,'eye'),E(2090,350,'knight'),E(2410,265,'eye'),E(2700,345,'knight'),E(3000,245,'eye')];
 say('Khu vực 1 — Hẻm núi hoàng hôn');
}
function E(px,py,t){return{x:px,y:py,w:32,h:38,vx:0,vy:0,hp:t==='knight'?50:32,t,dead:false,phase:Math.random()*7}}
function hit(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y}
function phys(o){o.vy+=.55;o.x+=o.vx;o.y+=o.vy;o.ground=false;for(const p of platforms)if(o.x+o.w>p[0]&&o.x<p[0]+p[2]&&o.y+o.h>=p[1]&&o.y+o.h<=p[1]+14&&o.vy>=0){o.y=p[1]-o.h;o.vy=0;o.ground=true}o.x=Math.max(0,Math.min(world-o.w,o.x))}
function jump(){if(P.ground){P.vy=-11.5;P.ground=false;}}
function atk(){if(P.atk<=0)P.atk=280}
function dash(){if(P.dash<=0){P.vx=P.face*13;P.inv=350;P.dash=900;burst(P.x,P.y+20,'#e1a8ff',10)}}
function spell(){if(P.skill<=0&&P.mp>=25){P.mp-=25;P.skill=700;shots.push({x:P.x+P.w/2,y:P.y+15,vx:P.face*10,life:1200});burst(P.x+P.w/2,P.y+15,'#41f3ff',18)}}
function sword(){return{x:P.face>0?P.x+5:P.x-52,y:P.y+3,w:52,h:38}}
function hurt(n){if(P.inv>0)return;P.hp-=n;P.inv=650;shake=9;burst(P.x+12,P.y+20,'#ff3565',12);if(P.hp<=0){P.hp=100;P.x=130;P.y=300;say('Bạn đã hồi sinh!')}}
function update(dt){
 let l=keys.a||keys.ArrowLeft||joyX<-.2,r=keys.d||keys.ArrowRight||joyX>.2;
 P.vx+=(r-l)*.65;P.vx*=.83;if(Math.abs(P.vx)>5)P.vx=Math.sign(P.vx)*5;if(l)P.face=-1;if(r)P.face=1;
 if(keys.jump){jump();keys.jump=false}if(keys.attack){atk();keys.attack=false}if(keys.skill){spell();keys.skill=false}if(keys.dash){dash();keys.dash=false}
 P.mp=Math.min(100,P.mp+dt*.012);P.atk=Math.max(0,P.atk-dt);P.skill=Math.max(0,P.skill-dt);P.dash=Math.max(0,P.dash-dt);P.inv=Math.max(0,P.inv-dt);phys(P);
 for(const e of enemies){if(e.dead)continue;e.phase+=dt*.005;e.vy+=.35;e.vx+=(P.x<e.x?-.06:.06);e.vx*=.96;phys(e);if(e.t==='eye')e.y+=Math.sin(e.phase)*.4;if(hit(P,e))hurt(e.t==='knight'?13:8);if(P.atk>80&&hit(sword(),e)){e.hp-=35;e.vx=P.face*6;burst(e.x+16,e.y+18,'#ff4de8',10);if(e.hp<=0){e.dead=true;kills++;gems+=e.t==='eye'?3:5;gold+=e.t==='eye'?30:80}}}
 for(const s of shots){s.x+=s.vx;s.life-=dt;for(const e of enemies)if(!e.dead&&Math.abs(s.x-e.x)<42&&Math.abs(s.y-e.y)<42){e.hp-=48;s.life=0;burst(e.x,e.y,'#56f7ff',18);if(e.hp<=0){e.dead=true;kills++;gems+=4}}}
 shots=shots.filter(s=>s.life>0);
 if(P.x>2850&&!boss){boss={x:3130,y:190,w:75,h:95,hp:420,max:420,vx:0,vy:0,hit:0,ground:false};say('⚠ HẮC NHÃN — THỦ LĨNH XUẤT HIỆN!');}
 if(boss&&!boss.dead){boss.hit=Math.max(0,boss.hit-dt);boss.vy+=.5;boss.vx+=(boss.x<P.x?.07:-.07);boss.vx*=.95;phys(boss);if(hit(P,boss))hurt(20);if(P.atk>80&&hit(sword(),boss)&&boss.hit<=0){boss.hp-=22;boss.hit=250;shake=6;burst(boss.x+35,boss.y+45,'#ff35e6',16)}if(Math.random()<.012){shots.push({x:boss.x,y:boss.y+40,vx:(P.x<boss.x?-5:5),life:1400,boss:true})}}
 for(const s of shots)if(s.boss&&Math.abs(s.x-P.x)<35&&Math.abs(s.y-P.y)<45)hurt(16);
 if(boss&&boss.hp<=0&&!boss.dead){boss.dead=true;gold+=1000;gems+=30;burst(boss.x+35,boss.y+45,'#fff',70);say('🏆 HẮC NHÃN ĐÃ BỊ ĐÁNH BẠI!',5000)}
 cam+=(P.x-W*.36-cam)*.09;cam=Math.max(0,Math.min(world-W,cam));shake*=.88;flash=Math.max(0,flash-dt);
 for(const q of parts){q.x+=q.vx;q.y+=q.vy;q.vy+=.05;q.life-=dt}parts=parts.filter(q=>q.life>0);
 document.getElementById('hp').style.width=P.hp+'%';document.getElementById('mp').style.width=P.mp+'%';document.getElementById('gems').textContent=gems;document.getElementById('gold').textContent=gold;document.getElementById('kills').textContent=kills;
 if(msgT>0){msgT-=dt;if(msgT<=0)hint.style.opacity=0}
}
function burst(px,py,col,n){for(let i=0;i<n;i++)parts.push({x:px,y:py,vx:(Math.random()-.5)*7,vy:(Math.random()-.5)*7,life:350+Math.random()*600,col})}
function bg(){
 let g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#73b9dd');g.addColorStop(.48,'#e4a56f');g.addColorStop(1,'#18222c');x.fillStyle=g;x.fillRect(0,0,W,H);
 x.fillStyle='#4b4e5c';for(let i=-300;i<world+500;i+=330){x.beginPath();x.moveTo(i,H*.72);x.lineTo(i+160,H*.32);x.lineTo(i+330,H*.72);x.fill()}
 x.fillStyle='#d8c1a5';x.globalAlpha=.35;for(let i=0;i<12;i++){x.beginPath();x.arc((i*210-cam*.12)% (W+300)-100,70+(i%3)*22,24+(i%4)*9,0,7);x.fill()}x.globalAlpha=1
}
function draw(){
 x.clearRect(0,0,W,H);bg();x.save();x.translate(-cam+(Math.random()-.5)*shake,-(Math.random()-.5)*shake);
 // cavern rocks and platforms
 for(const p of platforms){x.fillStyle='#252a2f';x.fillRect(...p);x.fillStyle='#3f4544';x.fillRect(p[0],p[1],p[2],5);x.fillStyle='#1b1e20';for(let xx=p[0]+15;xx<p[0]+p[2]-5;xx+=40){x.fillRect(xx,p[1]+9,18,4)}}
 // grass
 for(const p of platforms){x.strokeStyle='#6b8e55';x.lineWidth=3;for(let xx=p[0]+5;xx<p[0]+p[2];xx+=18){x.beginPath();x.moveTo(xx,p[1]);x.lineTo(xx+3,p[1]-7);x.stroke()}}
 for(const s of shots){if(s.boss){x.fillStyle='#ff31e8';x.shadowBlur=18;x.shadowColor='#ff31e8';x.beginPath();x.arc(s.x,s.y,8,0,7);x.fill();x.shadowBlur=0}else{drawSpell(s)}}
 for(const e of enemies)if(!e.dead)drawEnemy(e);
 if(boss&&!boss.dead)drawBoss(boss);drawPlayer();
 for(const q of parts){x.globalAlpha=Math.max(0,q.life/700);x.fillStyle=q.col;x.fillRect(q.x,q.y,4,4)}x.globalAlpha=1;x.restore();
 if(boss&&!boss.dead){x.fillStyle='#171321';x.fillRect(W*.25,18,W*.5,10);x.fillStyle='#cf39e9';x.fillRect(W*.25,18,W*.5*(boss.hp/boss.max),10)}
}
function drawPlayer(){x.save();x.translate(P.x+12,P.y+22);x.scale(P.face,1);if(P.inv>0&&Math.floor(P.inv/60)%2===0)x.globalAlpha=.45;
 x.fillStyle='#11131a';x.fillRect(-9,-4,18,23);x.fillStyle='#e6e6e2';x.fillRect(-7,-29,14,22);x.fillStyle='#0c0f15';x.fillRect(-8,-31,16,6);x.fillStyle='#11131a';x.fillRect(-8,19,6,8);x.fillRect(2,19,6,8);
 if(P.atk>0){x.rotate(-.35);x.fillStyle='#eef8ff';x.shadowBlur=12;x.shadowColor='#d04dff';x.fillRect(8,-3,48,4);x.shadowBlur=0}
 x.restore()}
function drawEnemy(e){x.save();x.translate(e.x+16,e.y+19);if(e.t==='eye'){x.fillStyle='#11131a';x.beginPath();x.ellipse(0,0,17,11,0,0,7);x.fill();x.fillStyle='#ff395b';x.beginPath();x.arc(3,0,6,0,7);x.fill();x.fillStyle='#0b0c10';x.beginPath();x.arc(4,0,2,0,7);x.fill();x.strokeStyle='#8b39f3';x.stroke()}else{x.fillStyle='#191b24';x.fillRect(-14,-18,28,34);x.fillStyle='#b99c86';x.fillRect(-9,-30,18,13);x.fillStyle='#f1d2a9';x.fillRect(-5,-27,3,3);x.fillRect(3,-27,3,3)}x.restore()}
function drawBoss(b){x.save();x.translate(b.x+37,b.y+47);x.fillStyle=b.hit?'#fff':'#161322';x.shadowBlur=25;x.shadowColor='#e32fff';x.fillRect(-33,-36,66,70);x.shadowBlur=0;x.fillStyle='#d7ad91';x.fillRect(-23,-57,46,25);x.fillStyle='#ff2ee9';x.beginPath();x.arc(-10,-45,5,0,7);x.arc(10,-45,5,0,7);x.fill();x.fillStyle='#e8f5ff';x.fillRect(18,-5,72,6);x.restore()}
function drawSpell(s){x.save();x.translate(s.x,s.y);x.strokeStyle='#4ff5ff';x.lineWidth=3;x.shadowBlur=14;x.shadowColor='#37eaff';x.beginPath();x.arc(0,0,13,0,7);x.stroke();x.beginPath();x.moveTo(-14,8);x.lineTo(0,-13);x.lineTo(14,8);x.stroke();x.restore()}
let joyX=0,joyY=0;
const joy=document.getElementById('joystick'),stick=joy.querySelector('.stick');let jid=null;
joy.addEventListener('pointerdown',e=>{jid=e.pointerId;joy.setPointerCapture(jid);moveJoy(e)});
joy.addEventListener('pointermove',e=>{if(e.pointerId===jid)moveJoy(e)});
joy.addEventListener('pointerup',()=>{joyX=joyY=0;stick.style.left='31px';stick.style.top='31px';jid=null});
function moveJoy(e){let r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.min(36,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);joyX=Math.cos(a)*(m/36);joyY=Math.sin(a)*(m/36);stick.style.left=31+joyX*28+'px';stick.style.top=31+joyY*28+'px';}
function bind(id,k){let b=document.getElementById(id);b.addEventListener('pointerdown',e=>{e.preventDefault();keys[k]=true});b.addEventListener('pointerup',e=>{e.preventDefault();keys[k]=false});b.addEventListener('pointercancel',()=>keys[k]=false)}
bind('jump','jump');bind('attack','attack');bind('skill','skill');bind('dash','dash');
addEventListener('keydown',e=>{keys[e.key]=true;if(e.key===' ')keys.jump=true;if(e.key.toLowerCase()==='j')keys.attack=true;if(e.key.toLowerCase()==='k')keys.skill=true;if(e.key.toLowerCase()==='l')keys.dash=true});
addEventListener('keyup',e=>keys[e.key]=false);
document.getElementById('play').onclick=()=>{start.style.display='none';reset();run=true;requestAnimationFrame(loop)};
function loop(t){if(!run)return;let dt=Math.min(34,t-last||16);last=t;update(dt);draw();requestAnimationFrame(loop)}
