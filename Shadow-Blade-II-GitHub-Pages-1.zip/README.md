# Shadow Blade II — mobile action platform demo

Bản v2 được thiết kế lại dựa trên video tham khảo: platform 2D dark-fantasy, joystick trái, cụm nút hành động phải, quái mắt bay, hiệu ứng phép tím/xanh, camera cuộn, nhiều tầng và boss.

Tất cả đồ họa trong bản này là đồ họa canvas tự tạo, không sao chép tài sản từ video.

## Upload GitHub Pages
Thay 3 file cũ bằng:
- index.html
- style.css
- game.js

Sau khi commit, GitHub Pages sẽ tự triển khai nếu repository đang dùng branch main và thư mục root.

## Điều khiển
Mobile: joystick, nhảy, đánh, phép, lướt.
PC: A/D hoặc ←/→; Space; J đánh; K phép; L lướt.
